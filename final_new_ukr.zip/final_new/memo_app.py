from PyQt5.QtWidgets import QApplication 

app = QApplication([])
